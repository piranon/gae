angular.module('category', [
  'ngRoute',
  'GAEAPI',
  'file-model',
  'angularUtils.directives.dirPagination',
  'ngCookies'
]);