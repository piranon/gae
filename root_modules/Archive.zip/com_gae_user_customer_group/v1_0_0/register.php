<?

	$config = array(
			"injection"=>array(
					"sub_menu_id"=>17
				),
			"menu_display"=>array(
					"addon_menu"=>array(
						"label"=>"Customer Group",
						"image"=>array(
							"normal"=>$curModule->file_url."icon/btn_dashboard_customer_customergroup.png",
							"hover"=>$curModule->file_url."icon/btn_dashboard_customer_customergroup_over.png",
							"active"=>$curModule->file_url."icon/btn_dashboard_customer_customergroup_active.png",
							"selected"=>$curModule->file_url."icon/btn_dashboard_customer_customergroup_active.png"
						)
					),
					"addon_card_info"=>array(
						"label"=>"Customer Group",
						"primary_image"=>$curModule->file_url."icon/icon_dashboard_customer_customergroup.png",
						"detail"=>array(
							"name"=>"Customer Group",
							"title_1"=>"หน้าแสดงกลุ่มของลูกค้า"
						)
					)
				)
		); 

?>

