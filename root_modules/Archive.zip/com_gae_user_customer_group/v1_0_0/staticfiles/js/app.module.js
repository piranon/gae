angular.module('customerGroup', [
  'ngRoute',
  'GAEAPI',
  'file-model',
  'angularUtils.directives.dirPagination',
  'autocomplete',
  'ngCookies'
]);