angular.module('staff', [
  'ngRoute',
  'GAEAPI',
  'file-model',
  'angularUtils.directives.dirPagination',
  'ngCookies'
]);