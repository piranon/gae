angular.module('customer', [
  'ngRoute',
  'GAEAPI',
  'file-model',
  'angularUtils.directives.dirPagination',
  'ngCookies'
]);