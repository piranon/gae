<?php

$config = array(
    "injection" => array(
        "sub_menu_id" => 17
    ),
    "menu_display" => array(
        "addon_menu" => array(
            "label" => "Customer",
            "image" => array(
                "normal" => $curModule->file_url . "icon/btn_dashboard_customer_customermanage.png",
                "hover" => $curModule->file_url . "icon/btn_dashboard_customer_customermanage_over.png",
                "active" => $curModule->file_url . "icon/btn_dashboard_customer_customermanage_active.png",
                "selected" => $curModule->file_url . "icon/btn_dashboard_customer_customermanage_active.png"
            )
        ),
        "addon_card_info" => array(
            "label" => "Customer",
            "primary_image" => $curModule->file_url . "icon/icon_dashboard_customer_customermanage.png",
            "detail" => array(
                "name" => "Customer",
                "title_1" => "หน้าแสดงลูกค้าของร้านทั้งหมด"
            )
        )
    )
);
